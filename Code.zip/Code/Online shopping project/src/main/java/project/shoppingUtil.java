package project;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

public class shoppingUtil {

	private Properties prop=null;

	public shoppingUtil() {
		loadCredentials(); // Call the method to load the credentials
	}

	private void loadCredentials(){

		try {

			InputStream fis= this.getClass().getResourceAsStream("credentials.properties"); // Get the credentials file as a stream
			prop=new Properties();
			prop.load(fis); // Load the properties from the stream

		} catch (Exception e) {
			System.out.println(e.getMessage()); // Print any exceptions that occur
		}
	}

	public String getAdminUser()
	{
		return prop.getProperty("adminUser"); // Return the value associated with the key "adminUser"
	}

	public String getAdminPassword()
	{
		return prop.getProperty("adminPassword"); // Return the value associated with the key "adminPassword"
	}

}
