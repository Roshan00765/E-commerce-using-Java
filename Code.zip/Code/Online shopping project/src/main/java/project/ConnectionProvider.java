package project;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ConnectionProvider {
	// Private instance variables to store database credentials
	private String dbHost="";
	private String dbPort="";
	private String dbUserName="";
	private String dbPassword="";
	private String dbName="";
	
	// Method to get a connection to the database
	public Connection getCon() {
		try {
			// Load the database credentials from properties file
			loadCredentials();
			// Register the MySQL driver
			Class.forName("com.mysql.jdbc.Driver");
			// Create a connection to the database using the credentials
			Connection con=DriverManager.getConnection("jdbc:mysql://" + dbHost + ":" + dbPort + "/" + dbName, dbUserName, dbPassword);
			return con;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return null;
		}
	}
	
	// Private method to load database credentials from properties file
	private void loadCredentials() throws Exception {
		try {
			// Load properties file using class loader
			InputStream fis= this.getClass().getResourceAsStream("dbCredentials.properties");
			Properties prop=new Properties();
			prop.load(fis);
			// Store the credentials in instance variables
			dbHost = prop.getProperty("dbHost");
			dbPort = prop.getProperty("dbPort");
			dbUserName = prop.getProperty("dbUserName");
			dbPassword = prop.getProperty("dbPassword");
			dbName = prop.getProperty("dbName");
		} catch (Exception e) {
			throw e;
		}
	}
}
